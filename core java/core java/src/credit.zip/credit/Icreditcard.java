package credit;

public interface Icreditcard 
{
public void show();
public void withdraw();
public void deposite();
public void increaselimit();
}
